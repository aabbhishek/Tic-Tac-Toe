# Tic-Tac-Toe
A single player tic tac toe game with user authentication. 

RUN index.php as index file.

-> All PHP files are in includes folder 
->Database  [ Sql ] file is in \Database\tic-tac-toe.sql import to mysql or phpmyadmin before use. Change includes/conn.php *
->JavaScript in js folder 
-> css in css folder   

Database ---------------------------

contains 4 cols->name, email, password, id[auto-inc].


-------------------------------
To Login 

use -> username: 1@gmail.com and password:1
or register.


------------
contact -
kumarabhishek.kumar97@gmail.com
